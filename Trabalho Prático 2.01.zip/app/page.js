function Home() {
    return (
        <>
        <h1>Padaria Pão Crocante (ou no sul Padaria Cacetinho Crocante)</h1>
        <p>Melhores pães (cacetinhos) do país.</p>
        </>
    );
    
}

export default Home;
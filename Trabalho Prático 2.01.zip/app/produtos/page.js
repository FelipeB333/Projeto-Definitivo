import {Produto} from "../../database/tabelas";

async function Produtos() {
    const produtos = await Produto.findAll();
    return(
        <>
          <h1>Lista de Produtos</h1>
          <a href="/produtos/cadastro">Cadastrar produto</a>
          <table border = "1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOME</th>
                    <th>DESCRIÇÃO</th>
                    <th>TIPO</th>
                    <th>PREÇO_UNITARIO</th>
                </tr>
            </thead>
          <tbody>
            {
                produtos.map(function(pro){
                    return (
                        <tr>
                            <td>{pro.id}</td>
                            <td>{pro.nome}</td>
                            <td>{pro.descricao}</td>
                            <td>{pro.tipo}</td>
                            <td>{pro.preco_unitario}</td>
                        </tr>
                    );
                })
            }
          </tbody>
          </table>
        </>
    );
}

export default Produtos;
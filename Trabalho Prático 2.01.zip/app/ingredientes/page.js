import {Ingrediente} from "../../database/tabelas";

async function Ingredientes() {
    const ingredientes = await Ingrediente.findAll();
    return(
        <>
          <h1>Lista de Fornecedores</h1>
          <a href="/ingredientes/cadastro">Cadastrar ingredientes</a>
          <table border = "1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOME</th>
                    <th>UNIDADE_MEDIA</th>
                    <th>ESTOQUE</th>
                    <th>PRECO_UNITARIO</th>
                </tr>
            </thead>
          <tbody>
            {
                ingredientes.map(function(ing){
                    return (
                        <tr key={ing.id}>
                            <td>{ing.id}</td>
                            <td>{ing.nome}</td>                                     
                            <td>{ing.unidade_media}</td>
                            <td>{ing.estoque}</td>
                            <td>{ing.preco_unitario}</td>
                        </tr>
                    );
                })
            }
          </tbody>
          </table>
        </>
    );
}

export default Ingredientes;
import {Cliente} from "../../database/tabelas";

async function Clientes() {
    const clientes = await Cliente.findAll();
    return(
        <>
          <h1>Lista de Clientes</h1>
          <a href="/clientes/cadastro">Cadastrar cliente</a>
          <table border = "1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOME</th>
                    <th>EMAIL</th>
                    <th>NASCIMENTO</th>
                    <th>CPF</th>
                </tr>
            </thead>
          <tbody>
            {
                clientes.map(function(cli){
                    return (
                        <tr key={cli.id}>
                            <td>{cli.id}</td>
                            <td>{cli.nome}</td>                                     
                            <td>{cli.email}</td>
                            <td>{cli.nascimento}</td>
                            <td>{cli.cpf}</td>
                        </tr>
                    );
                })
            }
          </tbody>
          </table>
        </>
    );
}

export default Clientes;
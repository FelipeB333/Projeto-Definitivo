import {Fornecedor} from "../../database/tabelas";

async function Fornecedores() {
    const fornecedores = await Fornecedor.findAll();
    return(
        <>
          <h1>Lista de Fornecedores</h1>
          <a href="/fornecedores/cadastro">Cadastrar fornecedor</a>
          <table border = "1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NOME</th>
                    <th>TIPO DE FORNECIMENTO</th>
                    <th>TELEFONE</th>
                    <th>CNPJ</th>
                </tr>
            </thead>
          <tbody>
            {
                fornecedores.map(function(forn){
                    return (
                        <tr key={forn.id}>
                            <td>{forn.id}</td>
                            <td>{forn.nome}</td>                                     
                            <td>{forn.tipo_fornecimento}</td>
                            <td>{forn.Telefone}</td>
                            <td>{forn.cnpj}</td>
                        </tr>
                    );
                })
            }
          </tbody>
          </table>
        </>
    );
}

export default Fornecedores;
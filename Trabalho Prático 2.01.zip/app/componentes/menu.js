function Menu() {
    return(
        <>
        <a href="/">Home</a>&nbsp;
        <br/>
        <a href="/produtos">Produtos</a>&nbsp;
        <a href="/clientes">Clientes</a>&nbsp;
        <a href="/fornecedores">Fornecedores</a>&nbsp;
        <a href="/ingredientes">Ingredientes</a>&nbsp;
        </>
    )
}

export default Menu;